var hideNotice = function(){
	$(".notice").fadeOut("slow");
}
setTimeout(hideNotice, 2000);
$(":file").filestyle({
	input: false
});
