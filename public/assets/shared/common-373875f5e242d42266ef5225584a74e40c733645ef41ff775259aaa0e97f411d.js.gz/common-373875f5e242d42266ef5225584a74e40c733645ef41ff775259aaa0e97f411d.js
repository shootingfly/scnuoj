var hideNotice = function(){
	$(".notice").fadeOut("slow");
}
setTimeout(hideNotice, 4000);
